<?php 
    $conn = mysqli_connect("localhost","root", "", "db_immamoto");

    // Cek Koneksi
    if (mysqli_connect_errno()) {
        echo "Failed to connect to MySQL : " . mysqli_connect_error();
        exit(); 
    }

    function query($query){
        global $conn;
        $result = mysqli_query($conn, $query);
        $rows = [];
        while ($row=mysqli_fetch_assoc($result)) {
            $rows[]=$row;
        }
        return $rows;
    }

    function registrasi($data){
        global $conn;
        $id = strtolower(stripslashes($data["id_user"]));
        $email = strtolower(stripslashes($data["email"]));
        $username = strtolower(stripslashes($data["username"]));
        $nomor_telepon = intval(stripslashes($data["nomor_telepon"]));
        $password = mysqli_real_escape_string($conn, $data["password"]);
        $password2 = mysqli_real_escape_string($conn, $data["password2"]);
        $result = mysqli_query($conn, "SELECT id FROM user WHERE id_user = '$id'");
        if (mysqli_fetch_assoc($result)) {
            echo "<script>
            alert('akun sudah terdaftar!');
            </script>";
            return false;
        }
        if ($password !== $password2) {
            echo "<script>
            alert('konfirmasi password tidak sesuai!');
            </script>";
            return false;
        }
        $password = password_hash($password, PASSWORD_DEFAULT);
        mysqli_query($conn, "INSERT INTO user VALUES ('', '$id', '$email', '$username','$nomor_telepon', '$password')");
        return mysqli_affected_rows($conn);
    }
?>
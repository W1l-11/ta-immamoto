    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>index</title>

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="main.css">
    </head>
    <body>

    <!-- Navbar --> 

    <div class="navbar">
    <div class="navbar-logo"><img src="Logo.png" alt=""></div>
    <div class="navbar-buttons">
        <!-- Tombol Daftar -->
        <button class="btn btn-daftar" onclick="window.location.href='signup.php'">Daftar</button>
        <!-- Tombol Masuk -->
        <button class="btn btn-masuk" onclick="window.location.href='login.php'">Masuk</button>
        <!-- Tombol Jual -->
        <button class="btn btn-jual" onclick="window.location.href='jual.php'">Jual</button>
    </div>
</div>

    <!-- Extended Navbar --> 

    <nav role="navigation" class="primary-navigation">
  <ul>
    <li><a href="#">Home</a></li>
    <li><a href="#">Kategori &dtrif;</a>
    <ul class="dropdown">
        <li><a href="#">Super Bike</a></li>
        <li><a href="#">Sports Bike</a></li>
        <li><a href="#">Scooter</a></li>
        <li><a href="#">Normal</a></li>
      </ul>
    <li>
        <a href="#">Pemakaian &dtrif;</a>
      <ul class="dropdown">
        <li><a href="#">Bekas</a></li>
        <li><a href="#">Baru</a></li>
      </ul>
    </li>
    <li><a href="#">Lokasi</a></li>
    <li><a href="#">Keranjang</a></li>
  </ul>
</nav>

<!-- Search and Filter Container -->
<div class="search-filter-container">
    <div class="search-bar">
        <input type="text" placeholder="Search" class="search-input">
        <button class="search-button"><img src="search.png" alt="Search"></button>
    </div>
    <button class="filter-button"><img src="filter.png" alt="Filter"></button>
    <div class="filter-dropdown" style="display:none;">
    <form>
        <div>
            <input type="checkbox" id="filter1" name="filter1">
            <label for="filter1">Filter Option 1</label>
        </div>
        <div>
            <input type="checkbox" id="filter2" name="filter2">
            <label for="filter2">Filter Option 2</label>
        </div>
        <div>
            <input type="checkbox" id="filter3" name="filter3">
            <label for="filter3">Filter Option 3</label>
        </div>
    </form>
</div>
</div>

<!-- Image Slider -->

<div class="slider">
  <div class="slides">
    <img src="cbr250rr.png" alt="">
    <img src="r6.jpeg" alt="">
    <img src="zx25r.png" alt="">
  </div>
</div>

<!-- Rekomendasi Subtitle and Line -->
<div class="recommendation-section">
    <h2>Rekomendasi</h2>
    <div class="line"></div>
</div>

<!-- Card motor -->

<div class="card-container">
    <!-- Card 1 -->
    <div class="product-card">
        <img src="motor1.png" alt="Motor 1">
        <div class="card-content">
            <h3>Motor 1</h3>
            <p>Rp 50.000.000</p>
        </div>
    </div>

    <!-- Card 2 -->
    <div class="product-card">
        <img src="motor1.png" alt="Motor 1">
        <div class="card-content">
            <h3>Motor 1</h3>
            <p>Rp 50.000.000</p>
        </div>
    </div>

    <!-- Card 3 -->
    <div class="product-card">
        <img src="motor1.png" alt="Motor 1">
        <div class="card-content">
            <h3>Motor 1</h3>
            <p>Rp 50.000.000</p>
        </div>
    </div>

    <!-- Card 4 -->
    <div class="product-card">
        <img src="motor1.png" alt="Motor 1">
        <div class="card-content">
            <h3>Motor 1</h3>
            <p>Rp 50.000.000</p>
        </div>
    </div>

    <!-- Card 5 -->
    <div class="product-card">
        <img src="motor1.png" alt="Motor 1">
        <div class="card-content">
            <h3>Motor 1</h3>
            <p>Rp 50.000.000</p>
        </div>
    </div>

    <!-- Card 6 -->
    <div class="product-card">
        <img src="motor1.png" alt="Motor 1">
        <div class="card-content">
            <h3>Motor 1</h3>
            <p>Rp 50.000.000</p>
        </div>
    </div>

    <!-- Card 7 -->
    <div class="product-card">
        <img src="motor1.png" alt="Motor 1">
        <div class="card-content">
            <h3>Motor 1</h3>
            <p>Rp 50.000.000</p>
        </div>
    </div>

    <!-- Card 8 -->
    <div class="product-card">
        <img src="motor1.png" alt="Motor 1">
        <div class="card-content">
            <h3>Motor 1</h3>
            <p>Rp 50.000.000</p>
        </div>
    </div>

    <!-- Card 9 -->
    <div class="product-card">
        <img src="motor1.png" alt="Motor 1">
        <div class="card-content">
            <h3>Motor 1</h3>
            <p>Rp 50.000.000</p>
        </div>
    </div>

    <!-- Card 10 -->
    <div class="product-card">
        <img src="motor1.png" alt="Motor 1">
        <div class="card-content">
            <h3>Motor 1</h3>
            <p>Rp 50.000.000</p>
        </div>
    </div>

    <!-- Card 11 -->
    <div class="product-card">
        <img src="motor1.png" alt="Motor 1">
        <div class="card-content">
            <h3>Motor 1</h3>
            <p>Rp 50.000.000</p>
        </div>
    </div>

    <!-- Card 12 -->
    <div class="product-card">
        <img src="motor1.png" alt="Motor 1">
        <div class="card-content">
            <h3>Motor 1</h3>
            <p>Rp 50.000.000</p>
        </div>
    </div>

    <!-- Card 13 -->
    <div class="product-card">
        <img src="motor1.png" alt="Motor 1">
        <div class="card-content">
            <h3>Motor 1</h3>
            <p>Rp 50.000.000</p>
        </div>
    </div>

    <!-- Card 14 -->
    <div class="product-card">
        <img src="motor1.png" alt="Motor 1">
        <div class="card-content">
            <h3>Motor 1</h3>
            <p>Rp 50.000.000</p>
        </div>
    </div>

    <!-- Card 15 -->
    <div class="product-card">
        <img src="motor1.png" alt="Motor 1">
        <div class="card-content">
            <h3>Motor 1</h3>
            <p>Rp 50.000.000</p>
        </div>
    </div>

    <!-- Card 16 -->
    <div class="product-card">
        <img src="motor1.png" alt="Motor 1">
        <div class="card-content">
            <h3>Motor 1</h3>
            <p>Rp 50.000.000</p>
        </div>
    </div>
</div>

<!-- Footer -->
<footer style="background-color: #6f1919; color: white; text-align: center; padding: 20px;">
    <div style="display: flex; justify-content: space-between;">
        <div style="flex-basis: 20%;">
            <h4>IMMAMOTO</h4>
            <ul style="list-style-type: none; padding-left: 0;">
                <li>Our Team</li>
                <li>Contact Support</li>
            </ul>
        </div>
        <div style="flex-basis: 20%;">
            <h4>Kategori Populer</h4>
            <ul style="list-style-type: none; padding-left: 0;">
                <li>Motor Sport</li>
                <li>Super Bike</li>
                <li>Naked Bike</li>
                <li>Normal Bike</li>
            </ul>
        </div>
        <div style="flex-basis: 20%;">
            <h4>Hubungi Kami</h4>
            <ul style="list-style-type: none; padding-left: 0;">
                <li>0812-3278-6221</li>
            </ul>
        </div>
        <div style="flex-basis: 20%;">
            <h4>Media Sosial</h4>
            <ul style="list-style-type: none; padding-left: 0;">
                <li><img src="instagram.png" alt="">@immamoto</li>
                <li><img src="facebook (1).png" alt="">@immamoto</li>
                <li><img src="twitter.png" alt="">@immamoto</li>
            </ul>
        </div>
    </div>
    <p>&copy; 2024 ImmaMoto. All Rights Reserved.</p>
</footer>

<script src="main.js"></script>
    </body>
    </html>
